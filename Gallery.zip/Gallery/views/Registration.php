<?php 
session_start();
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Registration</title>
        <link rel="stylesheet" type="text/css" href="../views/styles.css">
</head>
<body>
  <a href="../views/login.php">Login</a>
<div class="container">

	<form method="post" action="../controllers/RegistrationController.php" novalidate>
		
		<label>Registration Form</label>
		<input type="email" class="field" id="email" name="email" value="<?php echo empty($_SESSION['email']) ? "" :  $_SESSION['email'] ?>" Placeholder=" Enter Your Email" >
		<span><?php echo empty($_SESSION['err1']) ? "" :  $_SESSION['err1'] ?></span>
		

		<input type="password" class="field" id="password" name="password" value="<?php echo empty($_SESSION['password']) ? "" :  $_SESSION['password'] ?>" placeholder="Enter Your Password">
		<span><?php echo empty($_SESSION['err2']) ? "" :  $_SESSION['err2'] ?></span>
		

		<input type="password" class="field" id="confirm_password" name="confirm_password" value="<?php echo empty($_SESSION['confirm_password']) ? "" :  $_SESSION['confirm_password'] ?>" placeholder="Re-write Your Password">
		<span><?php echo empty($_SESSION['err3']) ? "" :  $_SESSION['err3'] ?></span>
		<br>

		<input type="submit" id="submit" value="Registration">
	</form>

	<?php echo empty($_SESSION['err4']) ? "" :  $_SESSION['err4'] ?>

</div>

</body>
</html>
